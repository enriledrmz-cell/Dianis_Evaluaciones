import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-analytics.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, collection, getDocs, deleteDoc, onSnapshot } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBHARbjc0KzNmRM_Ou8E0wSFxi1B7wm6mw",
  authDomain: "evaluaciones-2ac72.firebaseapp.com",
  projectId: "evaluaciones-2ac72",
  storageBucket: "evaluaciones-2ac72.firebasestorage.app",
  messagingSenderId: "1086437801223",
  appId: "1:1086437801223:web:399a48ea94042cdf6c59a2",
  measurementId: "G-NVS5PYSS1T"
};

const app = initializeApp(firebaseConfig);
let analytics = null;
try { analytics = getAnalytics(app); } catch (e) { console.warn('Analytics no disponible; la app continuará funcionando.', e); }
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();

let currentUser = null;
let unsubAlumnos = null;
let unsubEvals = null;
let unsubAsist = null;
let unsubObs = null;

// Evita que nombres y textos guardados se interpreten como HTML.
function esc(value){
  return String(value ?? '').replace(/[&<>\"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[ch]));
}

// ── UI de login ──
function showLoginUI(user){
  const bar = document.getElementById('fb-bar');
  if(!bar) return;
  if(user){
    bar.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <img src="${user.photoURL||''}" style="width:28px;height:28px;border-radius:50%;border:2px solid #7EDCB0" onerror="this.style.display='none'">
        <span style="color:#fff;font-family:Nunito,sans-serif;font-weight:700;font-size:.82rem">${user.displayName||user.email}</span>
        <span style="background:#7EDCB0;color:#1B4F72;border-radius:9px;padding:2px 10px;font-size:.72rem;font-family:Nunito,sans-serif;font-weight:800">☁️ Sincronizado</span>
        <button onclick="window.fbSignOut()" style="background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);color:#fff;border-radius:8px;padding:4px 12px;font-family:Nunito,sans-serif;font-weight:700;font-size:.75rem;cursor:pointer">Cerrar sesión</button>
      </div>`;
  } else {
    bar.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <span style="color:rgba(255,255,255,.7);font-family:Nunito,sans-serif;font-size:.82rem">💾 Guardando solo en este dispositivo</span>
        <button onclick="window.fbSignIn()" style="background:#7EDCB0;border:none;color:#1B4F72;border-radius:9px;padding:5px 16px;font-family:Nunito,sans-serif;font-weight:800;font-size:.82rem;cursor:pointer;display:flex;align-items:center;gap:6px">
          <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          Entrar con Google
        </button>
      </div>`;
  }
}

// ── Auth ──
window.fbSignIn = async () => {
  try {
    await signInWithPopup(auth, provider);
  } catch(e) {
    alert('Error al iniciar sesión: ' + e.message);
  }
};
window.fbSignOut = async () => {
  if(unsubAlumnos) unsubAlumnos();
  if(unsubEvals) unsubEvals();
  if(unsubAsist) unsubAsist();
  if(unsubObs) unsubObs();
  await signOut(auth);
};

// ── Firestore helpers ──
function userRef(path){ return doc(db, 'usuarios', currentUser.uid, ...path.split('/')); }
function userCol(path){ return collection(db, 'usuarios', currentUser.uid, path); }

// ── Sync listeners ──
function startSync(){
  // Alumnos
  if(unsubAlumnos) unsubAlumnos();
  unsubAlumnos = onSnapshot(userRef('datos/alumnos'), snap => {
    if(snap.exists()){
      const al = snap.data().lista || [];
      localStorage.setItem('d_al', JSON.stringify(al));
      if(typeof renderAl === 'function') renderAl();
    }
  });
  // Evaluaciones
  if(unsubEvals) unsubEvals();
  unsubEvals = onSnapshot(userRef('datos/evaluaciones'), snap => {
    if(snap.exists()){
      const ev = snap.data().lista || [];
      localStorage.setItem('d_ev', JSON.stringify(ev));
      if(typeof buildRS === 'function' && document.getElementById('tab-rs')?.classList.contains('active')) buildRS();
    }
  });
  // Asistencia
  if(unsubAsist) unsubAsist();
  unsubAsist = onSnapshot(userRef('datos/asistencia'), snap => {
    if(snap.exists()){
      const as = snap.data();
      localStorage.setItem('d_as', JSON.stringify(as));
      if(typeof buildAsistencia === 'function' && document.getElementById('tab-as')?.classList.contains('active')) buildAsistencia();
    }
  });
  // Observaciones
  if(unsubObs) unsubObs();
  unsubObs = onSnapshot(userRef('datos/observaciones'), snap => {
    if(snap.exists()){
      const ob = snap.data().lista || [];
      localStorage.setItem('d_ob', JSON.stringify(ob));
      if(typeof buildOb === 'function' && document.getElementById('tab-ob')?.classList.contains('active')) buildOb();
    }
  });
}

// ── Override save functions when logged in ──
function patchSaveFunctions(){
  window.sAl = function(lista){
    localStorage.setItem('d_al', JSON.stringify(lista));
    if(currentUser) setDoc(userRef('datos/alumnos'), {lista}, {merge:true}).catch(console.error);
  };
  window.sEv = function(lista){
    localStorage.setItem('d_ev', JSON.stringify(lista));
    if(currentUser) setDoc(userRef('datos/evaluaciones'), {lista}, {merge:true}).catch(console.error);
  };
  window.sAs = function(data){
    localStorage.setItem('d_as', JSON.stringify(data));
    if(currentUser) setDoc(userRef('datos/asistencia'), data, {merge:true}).catch(console.error);
  };
  window.sObs = function(lista){
    localStorage.setItem('d_ob', JSON.stringify(lista));
    if(currentUser) setDoc(userRef('datos/observaciones'), {lista}, {merge:true}).catch(console.error);
  };
}
patchSaveFunctions();

// ── Auth state ──
onAuthStateChanged(auth, async user => {
  currentUser = user;
  showLoginUI(user);
  if(user){
    startSync();
    // Subir datos locales si hay y nube está vacía
    const snap = await getDoc(userRef('datos/alumnos'));
    if(!snap.exists()){
      const localAl = JSON.parse(localStorage.getItem('d_al')||'[]');
      const localEv = JSON.parse(localStorage.getItem('d_ev')||'[]');
      const localAs = JSON.parse(localStorage.getItem('d_as')||'null');
      const localOb = JSON.parse(localStorage.getItem('d_ob')||'[]');
      if(localAl.length) await setDoc(userRef('datos/alumnos'), {lista: localAl});
      if(localEv.length) await setDoc(userRef('datos/evaluaciones'), {lista: localEv});
      if(localAs) await setDoc(userRef('datos/asistencia'), localAs);
      if(localOb.length) await setDoc(userRef('datos/observaciones'), {lista: localOb});
    }
  }
});
